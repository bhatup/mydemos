/**
 * Main application controller
 * 
 */
;(function() {

  angular.module('DashboardApp').controller('ProductController', ProductController);

  ProductController.$inject = ['$scope', 'site.config','QueryService','$rootScope','$timeout','$location', '$routeParams'];

  function ProductController($scope, SiteConfig, QueryService, $rootScope, $timeout, $location, $routeParams) {
  	var self = this;
	var productId = $routeParams.id;
	if(productId !== undefined && productId !=""){
		QueryService.queryRecentPurchaseData().then(function(response){
			var productlist = response.data;
			angular.forEach(productlist, function(value, key) {
			  if(value.id == productId){
				$scope.products = value;  	
			  }
			});
			
		});
	}else{
		QueryService.queryProductData().then(function(response){
			$scope.products = response.data;
		});
	}

	$rootScope.selectedMenu = $location.$$path;
  }


  angular.module('DashboardApp').controller('BrandController', BrandController);

  BrandController.$inject = ['$scope', 'site.config','QueryService','$rootScope','$timeout','$location'];

  function BrandController($scope, SiteConfig, QueryService, $rootScope, $timeout, $location) {

    var self = this;
	
	QueryService.queryBrandData().then(function(response){
		$scope.brands = response.data;
	});
	
	$rootScope.selectedMenu = $location.$$path;
  }


  angular.module('DashboardApp').controller('CategoryController', CategoryController);

  CategoryController.$inject = ['$scope', 'site.config','QueryService','$rootScope','$timeout','$location'];

  function CategoryController($scope, SiteConfig, QueryService, $rootScope, $timeout, $location) {

    var self = this;
	
	QueryService.queryCategoryData().then(function(response){
		$scope.categories = response.data;
	});
	$rootScope.selectedMenu = $location.$$path;
  }


  angular.module('DashboardApp').controller('ProductDetailsController', ProductDetailsController);

  ProductDetailsController.$inject = ['$scope', 'site.config','QueryService','$rootScope','$timeout','$location', '$routeParams'];

  function ProductDetailsController($scope, SiteConfig, QueryService, $rootScope, $timeout, $location, $routeParams) {

    var self = this;
	
	QueryService.queryCategoryData().then(function(response){
		$scope.categories = response.data;
	});
  }

})();