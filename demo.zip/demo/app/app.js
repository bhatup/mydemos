(function() {

  /**
   * Definition of the main app module and its dependencies
   */
  angular.module('DashboardApp', [
      'ngRoute'
    ]).config(config);

  // safe dependency injection
  config.$inject = ['$routeProvider', '$locationProvider', '$httpProvider'];

  /**
   * App routing
  */
  function config($routeProvider, $locationProvider, $httpProvider) {
    $locationProvider.html5Mode(false);
    // routes
    $routeProvider
      .when('/', {
        templateUrl: 'views/dashboard.html',
        controller: 'MainController',
        controllerAs: 'main'
      })
      .when('/products', {
        templateUrl: 'views/products-list.html',
        controller: 'ProductController',
        controllerAs: 'main'
      })
      .when('/products/:id', {
        templateUrl: 'views/product-details.html',
        controller: 'ProductController',
        controllerAs: 'main'
      })
      .when('/brands', {
        templateUrl: 'views/brands-list.html',
        controller: 'BrandController',
        controllerAs: 'main'
      })
      .when('/categories', {
        templateUrl: 'views/categories-list.html',
        controller: 'CategoryController',
        controllerAs: 'main'
      })
      .otherwise({
        redirectTo: '/'
      });
  }

  /**
   * Run block
   */
  angular.module('DashboardApp').run(run);
  run.$inject = ['$rootScope', '$location'];
  function run($rootScope, $location) {
    // put here everything that you need to run on page load
    $rootScope.selectedMenu = $location.$$path;
  }


})();