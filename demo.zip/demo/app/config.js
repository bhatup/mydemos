;(function() {
	/**
	 * Place to store API URL or any other constants
	 * Usage:
	 *
	 * Inject CONSTANTS service as a dependency and then use like this:
	 * CONSTANTS.API_URL
	 */
  angular.module('DashboardApp').constant('site.config', {
      	'APP_NAME': 'Merchant Dashboard',
		'PRODUCT_API_URL' : 'rest/productList.json',
		'RECENT_PURCHASE_API_URL' : 'rest/recentPurchaseList.json',
		'BRAND_API_URL' : 'rest/brand.json',
		'CATEGORY_API_URL' : 'rest/category.json'
    });

})();
