/**
 * Main application controller
 * 
 */
;(function() {
  angular.module('DashboardApp').controller('MainController', MainController);
  MainController.$inject = ['$scope','site.config','QueryService','$rootScope','$timeout','$location'];
  function MainController($scope, SiteConfig, QueryService, $rootScope, $timeout, $location) {
   	var self = this;
	QueryService.queryRecentPurchaseData().then(function(response){
		$scope.products = response.data;
	});
	
  }

})();